package com.multiMedia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultiMediaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MultiMediaApplication.class, args);
	}

}
